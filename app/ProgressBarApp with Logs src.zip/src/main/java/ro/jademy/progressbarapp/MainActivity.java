package ro.jademy.progressbarapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Random;

@SuppressLint("LongLogTag")
public class MainActivity extends ActionBarActivity {

    public static final String TAG = "ro.jademy.progressbarapp.MainActivity";

    // CTRL + ALT + L
    // ALT + ENTER
    ProgressBar bar;
    EditText edit;
    TextView text;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate()");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // View view = findViewById(R.id.progressBar);
        bar = (ProgressBar) findViewById(R.id.progressBar);
        edit = (EditText) findViewById(R.id.editText);
        text = (TextView) findViewById(R.id.george);
        button = (Button) findViewById(R.id.button);

        /*for (long i = 0; i < 5_000_000; i++) {
            int number = random.nextInt(11);
            s = s + number;
            text.setText("" + s);
        }*/
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    long s = 0;
    long i = 0;
    long iteratii = 5_000_000;
    Handler handler = new Handler();

    public void onClickButton(View view) {
        Log.i(TAG, "onClickButton");
        Editable editText = edit.getText();
        String stringText = editText.toString();
        if (!("".equals(stringText))) {
            Log.i(TAG, "if text not empty");
            try {
                iteratii = Integer.parseInt(stringText);
                Log.i(TAG, "successfully parsed text");
            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, e.getMessage());
            }
        } else {
            Log.i(TAG, "else text is empty");
        }
        bar.setMax((int) iteratii);
        Thread sumaRandom = new Thread(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "started running thread");
                Random random = new Random();
                for (i = 0; i < iteratii; i++) {
                   // Log.d(TAG, "i am at " + i + " iterations");
                    int number = random.nextInt(11);
                    s = s + number;
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            text.setText("" + s);
//                        }
//                    });
//                    text.post(new Runnable() {
//                        @Override
//                        public void run() {
//                            text.setText("" + s);
//                        }
//                    });
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            text.setText("" + s);
                            // bar.setProgress((int) (i * 100 / iteratii));
                            bar.setProgress((int) i);
                        }
                    });
                }
            }
        });
        sumaRandom.start();
    }
}







