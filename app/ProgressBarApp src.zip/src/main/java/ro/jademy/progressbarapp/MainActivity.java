package ro.jademy.progressbarapp;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Random;


public class MainActivity extends ActionBarActivity {

    // CTRL + ALT + L
    // ALT + ENTER
    ProgressBar bar;
    EditText edit;
    TextView text;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // View view = findViewById(R.id.progressBar);
        bar = (ProgressBar) findViewById(R.id.progressBar);
        edit = (EditText) findViewById(R.id.editText);
        text = (TextView) findViewById(R.id.george);
        button = (Button) findViewById(R.id.button);

        /*for (long i = 0; i < 5_000_000; i++) {
            int number = random.nextInt(11);
            s = s + number;
            text.setText("" + s);
        }*/
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    long s = 0;
    long i = 0;
    long iteratii = 5_000_000;

    public void onClickButton (View view) {
        Editable editText = edit.getText();
        String stringText = editText.toString();
        if (!("".equals(stringText))) {
            try {
                iteratii = Integer.parseInt(stringText);
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
        Thread sumaRandom = new Thread(new Runnable() {
            @Override
            public void run() {
                Random random = new Random();
                for (i = 0; i < iteratii; i++) {
                    int number = random.nextInt(11);
                    s = s + number;
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            text.setText("" + s);
//                        }
//                    });
//                    text.post(new Runnable() {
//                        @Override
//                        public void run() {
//                            text.setText("" + s);
//                        }
//                    });
                    Handler handler = new Handler();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            text.setText("" + s);
                            bar.setProgress((int) (i * 100 / iteratii));
                        }
                    });
                }
            }
        });
        sumaRandom.start();
    }
}







